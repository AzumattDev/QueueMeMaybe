| `Version` | `Update Notes`                |
|-----------|-------------------------------|
| 1.1.1     | - Update for Valehim 0.217.22 |
| 1.1.0     | - Updated for Valheim 0.216.9 |
| 1.0.0     | - Initial Release             |